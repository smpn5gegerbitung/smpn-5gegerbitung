import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  Menu, X, ChevronDown, ChevronRight, ChevronLeft, ArrowUp, MessageCircle,
  MapPin, Phone, Mail, Search, Calendar, Users, GraduationCap, BookOpen,
  Award, Newspaper, ImageIcon, Info, Home, Building2, Target, Heart, Shield,
  Star, Clock, Download, Filter, Plus, Edit, Trash2, LogOut, LayoutDashboard,
  FileText, UploadCloud, CheckCircle2, Sparkles, Quote, Facebook, Instagram,
  Youtube, Send, ArrowRight, Camera, Trophy, Music, Dumbbell, Laptop,
  BookMarked, HandHeart, ClipboardList, School, UserCog, Loader2, Leaf,
  Sprout, Compass, Layers, X as CloseIcon,
} from "lucide-react";

/* ============================================================
   GAYA & FONT
   ============================================================ */
const GlobalStyles = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap');

    .smpn5-root {
      --navy-deep: #082C4C;
      --navy: #0B3D66;
      --blue-mid: #1D6FA5;
      --blue-soft: #E7F1F8;
      --gold: #C9962C;
      --gold-light: #E8C468;
      --gold-pale: #FBF3E1;
      --ink: #10243B;
      --paper: #F6F8FB;
      --paper-alt: #FFFFFF;
      font-family: 'Inter', system-ui, sans-serif;
      color: var(--ink);
      background: var(--paper);
      -webkit-font-smoothing: antialiased;
    }
    .smpn5-root h1, .smpn5-root h2, .smpn5-root h3, .smpn5-root h4,
    .smpn5-root .font-display {
      font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
    }
    .bg-navy { background-color: var(--navy); }
    .bg-navy-deep { background-color: var(--navy-deep); }
    .bg-blue-mid { background-color: var(--blue-mid); }
    .bg-blue-soft { background-color: var(--blue-soft); }
    .bg-gold { background-color: var(--gold); }
    .bg-gold-pale { background-color: var(--gold-pale); }
    .text-navy { color: var(--navy); }
    .text-navy-deep { color: var(--navy-deep); }
    .text-blue-mid { color: var(--blue-mid); }
    .text-gold { color: var(--gold); }
    .border-gold { border-color: var(--gold); }
    .border-navy { border-color: var(--navy); }
    .grad-navy { background: linear-gradient(135deg, var(--navy-deep) 0%, var(--navy) 55%, var(--blue-mid) 100%); }
    .grad-gold { background: linear-gradient(120deg, var(--gold) 0%, var(--gold-light) 100%); }

    .btn-primary {
      background: var(--gold);
      color: var(--navy-deep);
      font-weight: 700;
      transition: all .25s ease;
    }
    .btn-primary:hover { background: var(--gold-light); transform: translateY(-2px); box-shadow: 0 10px 24px -8px rgba(201,150,44,.55); }
    .btn-outline {
      background: transparent;
      border: 1.5px solid rgba(255,255,255,.65);
      color: #fff;
      transition: all .25s ease;
    }
    .btn-outline:hover { background: rgba(255,255,255,.12); transform: translateY(-2px); }

    .card-elevate { transition: transform .3s ease, box-shadow .3s ease; }
    .card-elevate:hover { transform: translateY(-6px); box-shadow: 0 20px 40px -16px rgba(11,61,102,.28); }

    .fade-up { animation: fadeUp .7s ease both; }
    @keyframes fadeUp { from { opacity:0; transform: translateY(18px);} to {opacity:1; transform:translateY(0);} }
    .fade-in { animation: fadeIn .6s ease both; }
    @keyframes fadeIn { from{opacity:0} to{opacity:1} }

    /* Motif kawung -- identitas visual khas Jawa Barat, dipakai sebagai elemen pembeda */
    .kawung-divider {
      height: 22px;
      background-image: radial-gradient(circle at 50% 0%, var(--gold) 0 4px, transparent 5px);
      background-size: 26px 22px;
      background-repeat: repeat-x;
      opacity: .55;
    }
    .kawung-bg {
      background-image: radial-gradient(circle at 20px 20px, rgba(255,255,255,.09) 0 3px, transparent 4px),
                         radial-gradient(circle at 40px 40px, rgba(255,255,255,.09) 0 3px, transparent 4px);
      background-size: 40px 40px;
    }
    .kawung-bg-dark {
      background-image: radial-gradient(circle at 20px 20px, rgba(11,61,102,.06) 0 3px, transparent 4px),
                         radial-gradient(circle at 40px 40px, rgba(11,61,102,.06) 0 3px, transparent 4px);
      background-size: 40px 40px;
    }

    .no-scrollbar::-webkit-scrollbar { display: none; }
    .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }

    .line-clamp-2 { display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
    .line-clamp-3 { display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden; }
  `}</style>
);

/* ============================================================
   LOGO (placeholder — ganti dengan file logo resmi sekolah)
   ============================================================ */
const SchoolLogo = ({ size = 44 }) => (
  <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-label="Logo SMP Negeri 5 Gegerbitung">
    <path d="M32 3 L58 12 V30 C58 45 47 56 32 61 C17 56 6 45 6 30 V12 Z" fill="#0B3D66" stroke="#C9962C" strokeWidth="2"/>
    <path d="M32 3 L58 12 V30 C58 45 47 56 32 61 C17 56 6 45 6 30 V12 Z" fill="none" stroke="#082C4C" strokeWidth="1" opacity="0.4"/>
    <circle cx="32" cy="26" r="10" fill="#C9962C" opacity="0.95"/>
    <path d="M32 18 L36 26 L32 34 L28 26 Z" fill="#0B3D66"/>
    <text x="32" y="47" textAnchor="middle" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="800" fontSize="9" fill="#FFFFFF">SMPN 5</text>
  </svg>
);

/* ============================================================
   DATA DUMMY — GANTI DENGAN DATA ASLI SEKOLAH
   ============================================================ */
const SCHOOL = {
  name: "SMP Negeri 5 Gegerbitung",
  shortName: "SMPN 5 Gegerbitung",
  address: "Kecamatan Gegerbitung, Kabupaten Sukabumi, Jawa Barat", // GANTI DENGAN DATA ASLI SEKOLAH (alamat lengkap + kode pos)
  phone: "(0266) xxx-xxxx", // GANTI DENGAN DATA ASLI SEKOLAH
  whatsapp: "6281234567890", // GANTI DENGAN DATA ASLI SEKOLAH
  email: "info@smpn5gegerbitung.sch.id", // GANTI DENGAN DATA ASLI SEKOLAH
  npsn: "20xxxxxx", // GANTI DENGAN DATA ASLI SEKOLAH (NPSN resmi)
};

const STATS = [ // GANTI DENGAN DATA ASLI SEKOLAH
  { label: "Siswa Aktif", value: 512, icon: Users },
  { label: "Guru & Tendik", value: 38, icon: GraduationCap },
  { label: "Rombongan Belajar", value: 18, icon: Building2 },
  { label: "Ekstrakurikuler", value: 12, icon: Star },
  { label: "Prestasi Diraih", value: 64, icon: Trophy },
];

const TEACHERS = [ // GANTI DENGAN DATA ASLI SEKOLAH
  { name: "Dede Suryana, S.Pd., M.M.", nip: "19xxxxxxxxxxxxxxxx", role: "Kepala Sekolah", subject: "Bahasa Indonesia" },
  { name: "Rina Marlina, S.Pd.", nip: "19xxxxxxxxxxxxxxxx", role: "Wakil Kepala Sekolah", subject: "Matematika" },
  { name: "Asep Kurniawan, S.Pd.", nip: "19xxxxxxxxxxxxxxxx", role: "Guru", subject: "IPA" },
  { name: "Siti Nur Aisyah, S.Pd.", nip: "19xxxxxxxxxxxxxxxx", role: "Guru", subject: "IPS" },
  { name: "Hendra Gunawan, S.Pd.", nip: "19xxxxxxxxxxxxxxxx", role: "Guru", subject: "PJOK" },
  { name: "Yuli Astuti, S.Pd.", nip: "19xxxxxxxxxxxxxxxx", role: "Guru", subject: "Bahasa Inggris" },
  { name: "Budi Santoso, S.Kom.", nip: "19xxxxxxxxxxxxxxxx", role: "Guru", subject: "Informatika" },
  { name: "Neneng Ratnasari, S.Pd.I.", nip: "19xxxxxxxxxxxxxxxx", role: "Guru", subject: "Pendidikan Agama Islam" },
];

const PROGRAMS = [
  { key: "akademik", title: "Program Akademik", icon: BookOpen, desc: "Pembelajaran berdiferensiasi, literasi, numerasi, penguatan kompetensi, dan asesmen berkala.", items: ["Pembelajaran berdiferensiasi", "Program literasi", "Program numerasi", "Penguatan kompetensi siswa", "Asesmen dan evaluasi"] },
  { key: "kokurikuler", title: "Program Kokurikuler", icon: Sprout, desc: "Proyek penguatan profil pelajar Pancasila tahun ajaran 2026/2027 dengan tema, jadwal, dan hasil karya siswa.", items: ["Tema: Kearifan Lokal Sukabumi", "Tujuan: menumbuhkan gotong royong & kreativitas", "Jadwal: setiap Jumat, 3 kali per semester", "Dokumentasi & hasil karya siswa dipamerkan tiap akhir proyek"] },
  { key: "kesiswaan", title: "Program Kesiswaan", icon: Users, desc: "Wadah pembinaan organisasi, kepemimpinan, dan kepedulian sosial siswa.", items: ["OSIS", "MPLS", "Pembinaan karakter", "Kepemimpinan siswa", "Kegiatan sosial"] },
  { key: "karakter", title: "Pengembangan Karakter", icon: Heart, desc: "Menumbuhkan nilai-nilai luhur dalam keseharian siswa di sekolah.", items: ["Disiplin", "Tanggung jawab", "Gotong royong", "Kemandirian", "Kreativitas", "Kepedulian lingkungan"] },
  { key: "sehat", title: "Program Sekolah Sehat", icon: Leaf, desc: "Membiasakan pola hidup bersih dan sehat di lingkungan sekolah.", items: ["PHBS", "Kebersihan sekolah", "Senam pagi", "UKS", "Kantin sehat", "Gerakan hidup sehat"] },
  { key: "ramah-anak", title: "Sekolah Ramah Anak", icon: Shield, desc: "Menjamin lingkungan belajar yang aman, nyaman, dan bebas kekerasan bagi seluruh siswa.", items: ["Pencegahan perundungan", "Layanan konseling", "Partisipasi suara siswa", "Lingkungan inklusif"] },
  { key: "literasi", title: "Literasi & Numerasi", icon: BookMarked, desc: "Gerakan membaca dan berhitung yang dibiasakan setiap hari sebelum jam pelajaran dimulai.", items: ["15 menit membaca setiap pagi", "Pojok baca kelas", "Kompetisi numerasi", "Perpustakaan keliling"] },
  { key: "digital", title: "Digitalisasi Sekolah", icon: Laptop, desc: "Pemanfaatan teknologi untuk mendukung pembelajaran dan administrasi sekolah.", items: ["Pembelajaran berbasis TIK", "Administrasi digital", "Asesmen berbasis komputer", "Literasi digital siswa"] },
];

const ACTIVITY_CATEGORIES = {
  harian: { label: "Kegiatan Harian", items: [
    { name: "Pembiasaan Pagi", date: "Setiap hari, 06.45", desc: "Menyambut siswa, doa bersama, dan tadarus sebelum pelajaran dimulai." },
    { name: "Literasi Pagi", date: "Setiap hari, 07.00", desc: "Membaca 15 menit sebelum jam pelajaran pertama di setiap kelas." },
    { name: "Senam Pagi", date: "Setiap Jumat, 06.45", desc: "Senam bersama di lapangan sekolah untuk membiasakan hidup sehat." },
    { name: "Kegiatan Keagamaan", date: "Setiap hari, sesuai jadwal", desc: "Salat berjamaah dan pembinaan rohani sesuai agama masing-masing." },
    { name: "Kebersihan Lingkungan", date: "Setiap hari, piket kelas", desc: "Siswa menjaga kebersihan kelas dan lingkungan sekolah secara bergiliran." },
  ]},
  mingguan: { label: "Kegiatan Mingguan", items: [
    { name: "Ekstrakurikuler", date: "Setiap Sabtu, 08.00–11.00", desc: "Berbagai pilihan ekstrakurikuler minat dan bakat siswa." },
    { name: "Pembinaan Siswa", date: "Setiap Senin setelah upacara", desc: "Arahan dan motivasi dari kepala sekolah dan wali kelas." },
    { name: "Kegiatan Olahraga", date: "Setiap Rabu, jam PJOK", desc: "Latihan cabang olahraga di lapangan sekolah." },
    { name: "Kegiatan Seni", date: "Setiap Kamis, jam Seni Budaya", desc: "Latihan seni tari, musik, dan rupa bersama pembina." },
  ]},
  bulanan: { label: "Kegiatan Bulanan", items: [
    { name: "Projek Sekolah", date: "Minggu ke-3 setiap bulan", desc: "Presentasi hasil proyek kokurikuler tiap kelas." },
    { name: "Kegiatan Sosial", date: "Minggu ke-4 setiap bulan", desc: "Bakti sosial dan kunjungan ke lingkungan sekitar sekolah." },
    { name: "Kompetisi Siswa", date: "Terjadwal tiap bulan", desc: "Lomba akademik dan non-akademik antar kelas." },
  ]},
  tahunan: { label: "Kegiatan Tahunan", items: [
    { name: "MPLS", date: "Juli 2026", desc: "Masa pengenalan lingkungan sekolah bagi siswa baru." },
    { name: "Perayaan Hari Besar", date: "Sepanjang tahun ajaran", desc: "Peringatan hari besar nasional dan keagamaan." },
    { name: "Class Meeting", date: "Desember & Juni", desc: "Ajang kompetisi antar kelas usai penilaian akhir semester." },
    { name: "Pentas Seni", date: "Juni 2027", desc: "Pertunjukan bakat siswa di akhir tahun ajaran." },
    { name: "Pelepasan Siswa", date: "Juni 2027", desc: "Acara perpisahan siswa kelas IX." },
  ]},
};

const EXTRACURRICULARS = [
  { name: "Pramuka", pembina: "Hendra Gunawan, S.Pd.", jadwal: "Sabtu, 08.00–10.00", icon: Compass, desc: "Membentuk kemandirian, kedisiplinan, dan jiwa kepemimpinan siswa melalui kegiatan kepramukaan." },
  { name: "PMR", pembina: "Yuli Astuti, S.Pd.", jadwal: "Sabtu, 08.00–10.00", icon: Heart, desc: "Melatih kepedulian dan keterampilan pertolongan pertama." },
  { name: "Paskibra", pembina: "Asep Kurniawan, S.Pd.", jadwal: "Sabtu, 08.00–10.00", icon: Shield, desc: "Pembinaan baris-berbaris dan kedisiplinan untuk petugas upacara bendera." },
  { name: "Futsal", pembina: "Hendra Gunawan, S.Pd.", jadwal: "Sabtu, 10.00–12.00", icon: Dumbbell, desc: "Latihan rutin cabang olahraga futsal putra dan putri." },
  { name: "Seni Tari", pembina: "Neneng Ratnasari, S.Pd.I.", jadwal: "Sabtu, 08.00–10.00", icon: Music, desc: "Melestarikan seni tari tradisional dan kreasi baru." },
  { name: "Marawis / Keagamaan", pembina: "Neneng Ratnasari, S.Pd.I.", jadwal: "Sabtu, 10.00–12.00", icon: HandHeart, desc: "Pembinaan seni religi dan kajian keagamaan." },
  { name: "Klub Literasi", pembina: "Rina Marlina, S.Pd.", jadwal: "Sabtu, 08.00–10.00", icon: BookMarked, desc: "Wadah menulis, membaca, dan mengelola majalah dinding sekolah." },
  { name: "Klub IT / Digital", pembina: "Budi Santoso, S.Kom.", jadwal: "Sabtu, 10.00–12.00", icon: Laptop, desc: "Belajar dasar desain grafis, coding, dan pengelolaan media sekolah." },
];

const ACHIEVEMENTS = [ // GANTI DENGAN DATA ASLI SEKOLAH
  { name: "Ahmad Fauzan", kelas: "IX-A", lomba: "Olimpiade Matematika Tingkat Kabupaten", tingkat: "Kabupaten", hasil: "Juara 1", tanggal: "12 Mei 2026", kategori: "Akademik" },
  { name: "Salsabila Putri", kelas: "VIII-B", lomba: "Lomba Cipta Puisi", tingkat: "Kecamatan", hasil: "Juara 2", tanggal: "3 April 2026", kategori: "Seni" },
  { name: "Tim Futsal Putra", kelas: "IX", lomba: "Turnamen Futsal Pelajar", tingkat: "Kabupaten", hasil: "Juara 3", tanggal: "20 Maret 2026", kategori: "Olahraga" },
  { name: "Nabila Zahra", kelas: "VII-C", lomba: "MTQ Pelajar", tingkat: "Kecamatan", hasil: "Juara 1", tanggal: "15 Februari 2026", kategori: "Keagamaan" },
  { name: "Rizky Ramadhan", kelas: "VIII-A", lomba: "Lomba Cerdas Cermat IPA", tingkat: "Kabupaten", hasil: "Juara Harapan 1", tanggal: "28 Januari 2026", kategori: "Akademik" },
  { name: "Tim Paduan Suara", kelas: "Campuran", lomba: "Festival Paduan Suara Pelajar", tingkat: "Kabupaten", hasil: "Juara 2", tanggal: "10 Desember 2025", kategori: "Seni" },
];

const NEWS = [ // GANTI DENGAN DATA ASLI SEKOLAH
  { title: "Sosialisasi Program Kokurikuler Tahun Ajaran 2026/2027", date: "28 Agustus 2026", category: "Akademik", summary: "Sekolah menggelar sosialisasi tema dan jadwal Program Kokurikuler kepada seluruh wali kelas dan orang tua siswa.", popular: true },
  { title: "SMPN 5 Gegerbitung Raih Juara 1 Olimpiade Matematika Kabupaten", date: "13 Mei 2026", category: "Prestasi", summary: "Siswa kelas IX-A berhasil mengharumkan nama sekolah di ajang olimpiade tingkat kabupaten.", popular: true },
  { title: "Kegiatan Jumat Bersih dan Senam Sehat", date: "2 Mei 2026", category: "Kegiatan", summary: "Seluruh warga sekolah bergotong royong membersihkan lingkungan sekolah diikuti senam pagi bersama.", popular: false },
  { title: "Pembukaan Pendaftaran Peserta Didik Baru Segera Dibuka", date: "20 April 2026", category: "Pengumuman", summary: "Panitia PPDB mengumumkan jadwal sementara pendaftaran untuk tahun ajaran mendatang.", popular: true },
  { title: "Pelatihan Literasi Digital untuk Guru", date: "5 April 2026", category: "Akademik", summary: "Guru-guru mengikuti pelatihan pemanfaatan platform digital dalam pembelajaran sehari-hari.", popular: false },
  { title: "Peringatan Hari Kartini dengan Lomba Busana Adat", date: "21 April 2026", category: "Kegiatan", summary: "Siswa tampil mengenakan busana adat nusantara dalam rangka memperingati Hari Kartini.", popular: false },
];

const GALLERY_CATEGORIES = ["Semua", "Kegiatan Siswa", "Pembelajaran", "Ekstrakurikuler", "Prestasi", "Kegiatan Guru", "Kegiatan Sekolah", "Sarana Prasarana"];
const GALLERY_ITEMS = Array.from({ length: 16 }).map((_, i) => ({ // GANTI DENGAN DATA ASLI SEKOLAH (foto & video kegiatan sekolah)
  id: i + 1,
  category: GALLERY_CATEGORIES[(i % (GALLERY_CATEGORIES.length - 1)) + 1],
  title: `Dokumentasi Kegiatan ${i + 1}`,
  hue: [206, 40, 152, 260, 20, 190][i % 6],
}));

const AGENDA_ITEMS = [ // GANTI DENGAN DATA ASLI SEKOLAH
  { date: "1 September 2026", title: "Sosialisasi Program Kokurikuler", time: "08.00–10.00", place: "Laboratorium Komputer" },
  { date: "5 September 2026", title: "Rapat Wali Kelas dan Orang Tua", time: "09.00–11.00", place: "Aula Sekolah" },
  { date: "12 September 2026", title: "Lomba Kebersihan Antar Kelas", time: "07.00–selesai", place: "Lingkungan Sekolah" },
  { date: "20 September 2026", title: "Pelatihan Literasi Digital Guru", time: "13.00–15.00", place: "Ruang Guru" },
  { date: "28 September 2026", title: "Class Meeting Semester Ganjil", time: "07.00–selesai", place: "Lapangan Sekolah" },
];

const DOCUMENTS = [ // GANTI DENGAN DATA ASLI SEKOLAH
  { name: "Kalender Pendidikan 2026/2027", type: "PDF", size: "1.2 MB" },
  { name: "Formulir Pendaftaran PPDB", type: "PDF", size: "340 KB" },
  { name: "Jadwal Pelajaran Semester Ganjil", type: "PDF", size: "560 KB" },
  { name: "Panduan Orang Tua Siswa", type: "PDF", size: "890 KB" },
];

const ANNOUNCEMENTS = [ // GANTI DENGAN DATA ASLI SEKOLAH
  { title: "Libur Semester Ganjil", date: "20 Des 2026", desc: "Kegiatan belajar mengajar diliburkan mulai 20 Desember 2026 hingga 3 Januari 2027." },
  { title: "Pengumpulan Berkas PPDB Tahap 1", date: "10 Nov 2026", desc: "Calon peserta didik baru diharapkan melengkapi berkas paling lambat tanggal yang ditentukan." },
  { title: "Jadwal Vaksinasi Anak Sekolah", date: "2 Nov 2026", desc: "Bekerja sama dengan Puskesmas Kecamatan Gegerbitung untuk program imunisasi rutin." },
];

/* ============================================================
   KOMPONEN UI DASAR
   ============================================================ */
const Container = ({ children, className = "" }) => (
  <div className={`max-w-6xl mx-auto px-5 sm:px-8 ${className}`}>{children}</div>
);

const Eyebrow = ({ children }) => (
  <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-gold mb-3">
    <span className="w-6 h-px bg-gold inline-block" />
    {children}
  </div>
);

const SectionHeading = ({ eyebrow, title, desc, center = false }) => (
  <div className={`mb-10 ${center ? "text-center" : ""} fade-up`}>
    {eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}
    <h2 className="text-2xl sm:text-3xl font-extrabold text-navy-deep">{title}</h2>
    {desc && <p className={`mt-3 text-slate-600 leading-relaxed ${center ? "max-w-2xl mx-auto" : "max-w-2xl"}`}>{desc}</p>}
  </div>
);

const Badge = ({ children, tone = "gold" }) => {
  const tones = {
    gold: "bg-gold-pale text-navy-deep border border-gold/40",
    navy: "bg-blue-soft text-navy border border-navy/10",
  };
  return <span className={`inline-block text-[11px] font-bold px-2.5 py-1 rounded-full ${tones[tone]}`}>{children}</span>;
};

const PageIntro = ({ icon: Icon, title, desc, crumbs = [] }) => (
  <div className="grad-navy kawung-bg text-white">
    <Container className="py-14 sm:py-20">
      <nav className="flex flex-wrap items-center gap-1.5 text-xs text-white/70 mb-5 fade-in">
        <span className="hover:text-white cursor-default">Beranda</span>
        {crumbs.map((c, i) => (
          <span key={i} className="flex items-center gap-1.5">
            <ChevronRight size={12} /> <span className={i === crumbs.length - 1 ? "text-gold-light" : ""}>{c}</span>
          </span>
        ))}
      </nav>
      <div className="flex items-center gap-4 fade-up">
        {Icon && (
          <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/15 flex items-center justify-center shrink-0">
            <Icon size={26} className="text-gold-light" />
          </div>
        )}
        <div>
          <h1 className="text-2xl sm:text-4xl font-extrabold">{title}</h1>
          {desc && <p className="mt-2 text-white/75 max-w-2xl text-sm sm:text-base">{desc}</p>}
        </div>
      </div>
    </Container>
  </div>
);

const Tabs = ({ tabs, active, onChange }) => (
  <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 -mx-5 px-5 sm:mx-0 sm:px-0">
    {tabs.map((t) => (
      <button
        key={t.key}
        onClick={() => onChange(t.key)}
        className={`shrink-0 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all border ${
          active === t.key ? "bg-navy text-white border-navy shadow-md" : "bg-white text-slate-600 border-slate-200 hover:border-navy/40"
        }`}
      >
        {t.label}
      </button>
    ))}
  </div>
);

const FilterChips = ({ options, active, onChange }) => (
  <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 -mx-5 px-5 sm:mx-0 sm:px-0">
    {options.map((o) => (
      <button
        key={o}
        onClick={() => onChange(o)}
        className={`shrink-0 px-3.5 py-2 rounded-full text-xs font-bold uppercase tracking-wide transition-all border ${
          active === o ? "bg-gold text-navy-deep border-gold" : "bg-white text-slate-500 border-slate-200 hover:border-gold/60"
        }`}
      >
        {o}
      </button>
    ))}
  </div>
);

const Modal = ({ open, onClose, children, title }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-6" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-navy-deep/70 backdrop-blur-sm fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-t-3xl sm:rounded-3xl w-full sm:max-w-lg max-h-[88vh] overflow-y-auto fade-up shadow-2xl">
        <div className="sticky top-0 bg-white flex items-center justify-between px-5 py-4 border-b border-slate-100 z-10">
          <h3 className="font-bold text-navy-deep pr-4">{title}</h3>
          <button onClick={onClose} aria-label="Tutup" className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center shrink-0">
            <X size={18} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
};

const StatBlock = ({ icon: Icon, value, label }) => {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setSeen(true); }, { threshold: 0.4 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  useEffect(() => {
    if (!seen) return;
    let start = 0;
    const step = Math.max(1, Math.ceil(value / 40));
    const id = setInterval(() => {
      start += step;
      if (start >= value) { setCount(value); clearInterval(id); } else setCount(start);
    }, 25);
    return () => clearInterval(id);
  }, [seen, value]);
  return (
    <div ref={ref} className="flex flex-col items-center text-center gap-1.5 px-2">
      <Icon size={22} className="text-gold-light mb-1" />
      <div className="text-2xl sm:text-3xl font-extrabold text-white font-display">{count}+</div>
      <div className="text-[11px] sm:text-xs text-white/70 font-medium uppercase tracking-wide">{label}</div>
    </div>
  );
};

/* ============================================================
   HEADER
   ============================================================ */
const NAV_ITEMS = [
  { key: "beranda", label: "Beranda" },
  { key: "profil", label: "Profil", children: [
    { key: "tentang", label: "Tentang Sekolah" },
    { key: "sejarah", label: "Sejarah Sekolah" },
    { key: "visi-misi", label: "Visi dan Misi" },
    { key: "struktur", label: "Struktur Organisasi" },
    { key: "kepsek", label: "Kepala Sekolah" },
    { key: "guru", label: "Guru dan Tenaga Kependidikan" },
    { key: "sarpras", label: "Sarana dan Prasarana" },
  ]},
  { key: "program", label: "Program Sekolah" },
  { key: "kegiatan", label: "Kegiatan Siswa" },
  { key: "ekskul", label: "Ekstrakurikuler" },
  { key: "akademik", label: "Akademik", children: [
    { key: "kurikulum", label: "Kurikulum" },
    { key: "kalender", label: "Kalender Pendidikan" },
    { key: "jadwal", label: "Jadwal Pelajaran" },
    { key: "pembelajaran", label: "Program Pembelajaran" },
    { key: "asesmen", label: "Asesmen" },
    { key: "kelulusan", label: "Kriteria Kelulusan" },
  ]},
  { key: "prestasi", label: "Prestasi" },
  { key: "berita", label: "Berita" },
  { key: "galeri", label: "Galeri" },
  { key: "informasi", label: "Informasi" },
  { key: "kontak", label: "Kontak" },
];

const Header = ({ page, subTab, goTo, onSearch }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openDrop, setOpenDrop] = useState(null);
  const [mobileExpand, setMobileExpand] = useState(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? "bg-white/95 backdrop-blur shadow-md" : "bg-white/90 backdrop-blur"}`}>
      <div className="hidden sm:flex bg-navy-deep text-white/80 text-xs">
        <Container className="flex items-center justify-between py-1.5">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5"><MapPin size={12}/> {SCHOOL.address}</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5"><Mail size={12}/> {SCHOOL.email}</span>
            <span className="flex items-center gap-1.5"><Phone size={12}/> {SCHOOL.phone}</span>
          </div>
        </Container>
      </div>
      <Container className="flex items-center justify-between py-3">
        <button onClick={() => goTo("beranda")} className="flex items-center gap-2.5 text-left shrink-0">
          <SchoolLogo size={42} />
          <div className="leading-tight">
            <div className="font-extrabold text-navy-deep text-sm sm:text-base font-display">{SCHOOL.name}</div>
            <div className="text-[10px] sm:text-xs text-slate-500 tracking-wide">Kab. Sukabumi, Jawa Barat</div>
          </div>
        </button>

        <nav className="hidden lg:flex items-center gap-0.5">
          {NAV_ITEMS.map((item) => (
            <div key={item.key} className="relative" onMouseEnter={() => setOpenDrop(item.key)} onMouseLeave={() => setOpenDrop(null)}>
              <button
                onClick={() => goTo(item.key)}
                className={`flex items-center gap-1 px-3 py-2 rounded-lg text-[13px] font-semibold transition-colors ${
                  page === item.key ? "text-navy bg-blue-soft" : "text-slate-600 hover:text-navy hover:bg-blue-soft/60"
                }`}
              >
                {item.label}
                {item.children && <ChevronDown size={13} />}
              </button>
              {item.children && openDrop === item.key && (
                <div className="absolute top-full left-0 pt-2 w-64 fade-in">
                  <div className="bg-white rounded-xl shadow-xl border border-slate-100 py-2 overflow-hidden">
                    {item.children.map((c) => (
                      <button
                        key={c.key}
                        onClick={() => goTo(item.key, c.key)}
                        className={`w-full text-left px-4 py-2.5 text-[13px] hover:bg-blue-soft transition-colors ${
                          page === item.key && subTab === c.key ? "text-navy font-bold bg-blue-soft" : "text-slate-600"
                        }`}
                      >
                        {c.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </nav>

        <div className="flex items-center gap-1.5">
          <button onClick={() => setSearchOpen((v) => !v)} aria-label="Cari" className="w-10 h-10 rounded-full hover:bg-blue-soft flex items-center justify-center text-navy">
            <Search size={18} />
          </button>
          <button onClick={() => goTo("agenda")} className="hidden md:flex btn-primary px-4 py-2.5 rounded-full text-xs items-center gap-1.5">
            <Calendar size={14} /> Agenda
          </button>
          <button onClick={() => setMobileOpen(true)} className="lg:hidden w-10 h-10 rounded-full hover:bg-blue-soft flex items-center justify-center text-navy" aria-label="Buka menu">
            <Menu size={22} />
          </button>
        </div>
      </Container>

      {searchOpen && (
        <div className="border-t border-slate-100 bg-white fade-in">
          <Container className="py-3 flex items-center gap-2">
            <Search size={16} className="text-slate-400" />
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") { onSearch(query); setSearchOpen(false); } }}
              placeholder="Cari berita, program, informasi..."
              className="flex-1 outline-none text-sm py-1.5"
            />
            <button onClick={() => { onSearch(query); setSearchOpen(false); }} className="text-xs font-bold text-navy">Cari</button>
          </Container>
        </div>
      )}

      {/* Menu mobile */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[110] lg:hidden">
          <div className="absolute inset-0 bg-navy-deep/60" onClick={() => setMobileOpen(false)} />
          <div className="absolute right-0 top-0 bottom-0 w-[82%] max-w-xs bg-white shadow-2xl overflow-y-auto fade-in">
            <div className="flex items-center justify-between p-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <SchoolLogo size={32} />
                <span className="font-bold text-navy-deep text-sm">{SCHOOL.shortName}</span>
              </div>
              <button onClick={() => setMobileOpen(false)} className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center"><X size={18}/></button>
            </div>
            <div className="p-3">
              {NAV_ITEMS.map((item) => (
                <div key={item.key} className="border-b border-slate-50 last:border-0">
                  <button
                    onClick={() => {
                      if (item.children) setMobileExpand(mobileExpand === item.key ? null : item.key);
                      else { goTo(item.key); setMobileOpen(false); }
                    }}
                    className={`w-full flex items-center justify-between px-3 py-3.5 text-sm font-semibold rounded-lg ${page === item.key ? "text-navy bg-blue-soft" : "text-slate-700"}`}
                  >
                    {item.label}
                    {item.children && <ChevronDown size={16} className={`transition-transform ${mobileExpand === item.key ? "rotate-180" : ""}`} />}
                  </button>
                  {item.children && mobileExpand === item.key && (
                    <div className="pl-4 pb-2 fade-in">
                      {item.children.map((c) => (
                        <button
                          key={c.key}
                          onClick={() => { goTo(item.key, c.key); setMobileOpen(false); }}
                          className="w-full text-left px-3 py-2.5 text-[13px] text-slate-500 hover:text-navy rounded-lg"
                        >
                          {c.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

/* ============================================================
   FOOTER
   ============================================================ */
const Footer = ({ goTo, openAdmin }) => (
  <footer className="bg-navy-deep text-white/80 kawung-bg">
    <Container className="py-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
      <div>
        <div className="flex items-center gap-2.5 mb-4">
          <SchoolLogo size={38} />
          <span className="font-extrabold text-white text-sm leading-tight">{SCHOOL.name}</span>
        </div>
        <p className="text-xs leading-relaxed text-white/60">Mendidik, menginspirasi, dan membentuk generasi berkarakter di Kecamatan Gegerbitung, Kabupaten Sukabumi.</p>
        <div className="flex gap-2 mt-4">
          {[Facebook, Instagram, Youtube].map((Icon, i) => (
            <a key={i} href="#" onClick={(e) => e.preventDefault()} className="w-9 h-9 rounded-full bg-white/10 hover:bg-gold hover:text-navy-deep flex items-center justify-center transition-colors">
              <Icon size={15} />
            </a>
          ))}
        </div>
      </div>
      <div>
        <h4 className="text-white font-bold text-sm mb-4">Menu Cepat</h4>
        <ul className="space-y-2.5 text-xs">
          {[["profil","Profil"],["program","Program Sekolah"],["kegiatan","Kegiatan Siswa"],["berita","Berita"],["galeri","Galeri"],["kontak","Kontak"]].map(([k,l]) => (
            <li key={k}><button onClick={() => goTo(k)} className="hover:text-gold-light transition-colors">{l}</button></li>
          ))}
        </ul>
      </div>
      <div>
        <h4 className="text-white font-bold text-sm mb-4">Informasi</h4>
        <ul className="space-y-2.5 text-xs">
          {[["akademik","Akademik"],["prestasi","Prestasi"],["agenda","Agenda Sekolah"],["informasi","PPDB & Pengumuman"]].map(([k,l]) => (
            <li key={k}><button onClick={() => goTo(k)} className="hover:text-gold-light transition-colors">{l}</button></li>
          ))}
        </ul>
      </div>
      <div>
        <h4 className="text-white font-bold text-sm mb-4">Kontak</h4>
        <ul className="space-y-2.5 text-xs">
          <li className="flex gap-2"><MapPin size={14} className="shrink-0 mt-0.5"/> {SCHOOL.address}</li>
          <li className="flex gap-2"><Phone size={14} className="shrink-0 mt-0.5"/> {SCHOOL.phone}</li>
          <li className="flex gap-2"><Mail size={14} className="shrink-0 mt-0.5"/> {SCHOOL.email}</li>
        </ul>
      </div>
    </Container>
    <div className="border-t border-white/10">
      <Container className="py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-white/50">
        <span>© 2026 {SCHOOL.name}. All Rights Reserved.</span>
        <button onClick={openAdmin} className="flex items-center gap-1.5 hover:text-gold-light transition-colors"><UserCog size={13}/> Login Admin</button>
      </Container>
    </div>
  </footer>
);

const WhatsAppFab = () => (
  <a
    href={`https://wa.me/${SCHOOL.whatsapp}`}
    target="_blank" rel="noreferrer"
    className="fixed bottom-5 left-5 z-40 w-13 h-13 sm:w-14 sm:h-14 rounded-full bg-[#25D366] shadow-xl flex items-center justify-center text-white card-elevate"
    style={{ width: 52, height: 52 }}
    aria-label="Hubungi via WhatsApp"
  >
    <MessageCircle size={24} />
  </a>
);

const BackToTop = () => {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 500);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  if (!show) return null;
  return (
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className="fixed bottom-5 right-5 z-40 w-13 h-13 rounded-full bg-navy shadow-xl flex items-center justify-center text-white card-elevate"
      style={{ width: 52, height: 52 }}
      aria-label="Kembali ke atas"
    >
      <ArrowUp size={20} />
    </button>
  );
};

/* ============================================================
   HALAMAN: BERANDA
   ============================================================ */
const Beranda = ({ goTo }) => (
  <div>
    <div className="relative grad-navy kawung-bg text-white overflow-hidden">
      <div className="absolute -right-24 -top-24 w-96 h-96 rounded-full bg-gold/10 blur-3xl" />
      <div className="absolute -left-16 bottom-0 w-72 h-72 rounded-full bg-blue-mid/20 blur-3xl" />
      <Container className="relative py-20 sm:py-28">
        <div className="max-w-2xl fade-up">
          <Badge tone="gold">Sekolah Menengah Pertama Negeri</Badge>
          <h1 className="mt-5 text-3xl sm:text-5xl font-extrabold leading-tight font-display">
            Selamat Datang di <span className="text-gold-light">SMP Negeri 5 Gegerbitung</span>
          </h1>
          <p className="mt-5 text-white/80 text-base sm:text-lg leading-relaxed">
            "Mendidik, Menginspirasi, dan Membentuk Generasi Berkarakter"
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <button onClick={() => goTo("profil", "tentang")} className="btn-primary px-6 py-3.5 rounded-full text-sm flex items-center gap-2">
              Lihat Profil Sekolah <ArrowRight size={16} />
            </button>
            <button onClick={() => goTo("kegiatan")} className="btn-outline px-6 py-3.5 rounded-full text-sm">
              Kegiatan Sekolah
            </button>
          </div>
        </div>
      </Container>
      <div className="border-t border-white/10 bg-navy-deep/40">
        <Container className="py-8 grid grid-cols-3 sm:grid-cols-5 gap-6">
          {STATS.map((s) => <StatBlock key={s.label} {...s} />)}
        </Container>
      </div>
    </div>
    <div className="kawung-divider" />

    {/* Sambutan Kepala Sekolah */}
    <Container className="py-16 sm:py-20">
      <div className="grid md:grid-cols-[280px_1fr] gap-10 items-center">
        <div className="fade-up">
          <div className="rounded-3xl overflow-hidden shadow-xl border border-slate-100 aspect-[3/4] bg-gradient-to-br from-blue-soft to-white flex items-center justify-center">
            <Users size={72} className="text-navy/25" />
          </div>
        </div>
        <div className="fade-up">
          <Eyebrow>Sambutan</Eyebrow>
          <Quote size={30} className="text-gold/40 mb-3" />
          <p className="text-slate-600 leading-relaxed text-[15px] sm:text-base">
            Assalamu'alaikum warahmatullahi wabarakatuh. Selamat datang di laman resmi SMP Negeri 5 Gegerbitung. Kami berkomitmen menghadirkan proses belajar yang bermakna, membentuk karakter yang kuat, dan membekali siswa dengan keterampilan yang relevan bagi masa depan mereka. Semoga kehadiran website ini dapat mempererat komunikasi antara sekolah, orang tua, dan masyarakat.
          </p>
          <div className="mt-6">
            <div className="font-bold text-navy-deep">{/* GANTI DENGAN DATA ASLI SEKOLAH */}Dede Suryana, S.Pd., M.M.</div>
            <div className="text-xs text-slate-500">Kepala SMP Negeri 5 Gegerbitung</div>
          </div>
        </div>
      </div>
    </Container>

    {/* Akses cepat */}
    <div className="bg-blue-soft/50">
      <Container className="py-16 sm:py-20">
        <SectionHeading eyebrow="Akses Cepat" title="Jelajahi Informasi Sekolah" center />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { key: "program", icon: Target, label: "Program Sekolah" },
            { key: "kegiatan", icon: Sparkles, label: "Kegiatan Siswa" },
            { key: "prestasi", icon: Trophy, label: "Prestasi" },
            { key: "galeri", icon: ImageIcon, label: "Galeri" },
          ].map((a) => (
            <button key={a.key} onClick={() => goTo(a.key)} className="card-elevate bg-white rounded-2xl p-5 sm:p-6 text-center border border-slate-100 shadow-sm">
              <div className="w-12 h-12 rounded-xl bg-blue-soft flex items-center justify-center mx-auto mb-3">
                <a.icon size={22} className="text-navy" />
              </div>
              <div className="text-xs sm:text-sm font-bold text-navy-deep">{a.label}</div>
            </button>
          ))}
        </div>
      </Container>
    </div>

    {/* Berita terbaru */}
    <Container className="py-16 sm:py-20">
      <div className="flex items-end justify-between flex-wrap gap-4">
        <SectionHeading eyebrow="Berita & Informasi" title="Kabar Terbaru Sekolah" />
        <button onClick={() => goTo("berita")} className="text-navy font-bold text-sm flex items-center gap-1 mb-10">
          Semua berita <ChevronRight size={16} />
        </button>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {NEWS.slice(0, 3).map((n, i) => (
          <div key={i} className="card-elevate bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm">
            <div className="h-36 grad-navy kawung-bg flex items-center justify-center">
              <Newspaper size={30} className="text-white/40" />
            </div>
            <div className="p-5">
              <Badge tone="navy">{n.category}</Badge>
              <h3 className="mt-3 font-bold text-navy-deep leading-snug line-clamp-2">{n.title}</h3>
              <p className="mt-2 text-xs text-slate-500 line-clamp-2">{n.summary}</p>
              <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1"><Clock size={12}/>{n.date}</span>
                <button onClick={() => goTo("berita")} className="text-navy font-bold">Baca →</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Container>

    {/* Agenda mendatang */}
    <div className="bg-navy-deep kawung-bg text-white">
      <Container className="py-16 sm:py-20">
        <div className="flex items-end justify-between flex-wrap gap-4 mb-10">
          <div>
            <Eyebrow>Agenda Sekolah</Eyebrow>
            <h2 className="text-2xl sm:text-3xl font-extrabold">Kegiatan yang Akan Datang</h2>
          </div>
          <button onClick={() => goTo("agenda")} className="text-gold-light font-bold text-sm flex items-center gap-1">
            Lihat semua agenda <ChevronRight size={16} />
          </button>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {AGENDA_ITEMS.slice(0, 3).map((a, i) => (
            <div key={i} className="bg-white/5 border border-white/10 rounded-2xl p-5 card-elevate">
              <div className="flex items-center gap-2 text-gold-light text-xs font-bold mb-3"><Calendar size={14}/>{a.date}</div>
              <h4 className="font-bold">{a.title}</h4>
              <div className="mt-3 text-xs text-white/60 space-y-1">
                <div className="flex items-center gap-1.5"><Clock size={12}/>{a.time}</div>
                <div className="flex items-center gap-1.5"><MapPin size={12}/>{a.place}</div>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </div>
  </div>
);

/* ============================================================
   HALAMAN: PROFIL
   ============================================================ */
const PROFIL_TABS = [
  { key: "tentang", label: "Tentang" },
  { key: "sejarah", label: "Sejarah" },
  { key: "visi-misi", label: "Visi & Misi" },
  { key: "struktur", label: "Struktur" },
  { key: "kepsek", label: "Kepala Sekolah" },
  { key: "guru", label: "Guru & Tendik" },
  { key: "sarpras", label: "Sarana Prasarana" },
];

const Profil = ({ subTab, setSubTab }) => {
  const tab = subTab || "tentang";
  return (
    <div>
      <PageIntro icon={School} title="Profil Sekolah" desc="Mengenal lebih dekat identitas, sejarah, dan sumber daya SMP Negeri 5 Gegerbitung." crumbs={["Profil"]} />
      <Container className="py-12 sm:py-16">
        <Tabs tabs={PROFIL_TABS} active={tab} onChange={setSubTab} />
        <div className="mt-10 fade-in">
          {tab === "tentang" && (
            <div className="grid md:grid-cols-3 gap-8">
              <div className="md:col-span-2 space-y-4 text-slate-600 leading-relaxed">
                <p>SMP Negeri 5 Gegerbitung merupakan sekolah menengah pertama negeri yang berlokasi di Kecamatan Gegerbitung, Kabupaten Sukabumi, Jawa Barat. Sekolah ini berkomitmen menghadirkan layanan pendidikan yang bermutu, inklusif, dan berorientasi pada pembentukan karakter peserta didik.</p>
                <p>Dengan dukungan tenaga pendidik yang kompeten dan lingkungan belajar yang kondusif, SMP Negeri 5 Gegerbitung terus berupaya menjadi sekolah pilihan masyarakat di wilayah Gegerbitung dan sekitarnya.</p>
              </div>
              <div className="bg-blue-soft/60 rounded-2xl p-6 space-y-3 text-sm h-fit">
                <div className="flex justify-between border-b border-navy/10 pb-2"><span className="text-slate-500">NPSN</span><span className="font-bold text-navy-deep">{SCHOOL.npsn}</span></div>
                <div className="flex justify-between border-b border-navy/10 pb-2"><span className="text-slate-500">Status</span><span className="font-bold text-navy-deep">Negeri</span></div>
                <div className="flex justify-between border-b border-navy/10 pb-2"><span className="text-slate-500">Jenjang</span><span className="font-bold text-navy-deep">SMP</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Kabupaten</span><span className="font-bold text-navy-deep">Sukabumi</span></div>
              </div>
            </div>
          )}
          {tab === "sejarah" && (
            <div className="max-w-2xl text-slate-600 leading-relaxed space-y-4">
              <p>{/* GANTI DENGAN DATA ASLI SEKOLAH */}SMP Negeri 5 Gegerbitung didirikan untuk menjawab kebutuhan pendidikan menengah pertama bagi masyarakat di wilayah Kecamatan Gegerbitung. Sejak awal berdiri, sekolah terus berkembang baik dari sisi sarana, jumlah peserta didik, maupun capaian akademik dan non-akademik.</p>
              <p>Perjalanan panjang ini dijalani dengan semangat gotong royong dari seluruh warga sekolah, orang tua, dan masyarakat sekitar, sehingga SMP Negeri 5 Gegerbitung dapat terus tumbuh menjadi lembaga pendidikan yang dipercaya.</p>
            </div>
          )}
          {tab === "visi-misi" && (
            <div className="grid sm:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl p-7 border border-slate-100 shadow-sm">
                <div className="w-11 h-11 rounded-xl bg-gold-pale flex items-center justify-center mb-4"><Target size={20} className="text-gold"/></div>
                <h3 className="font-bold text-navy-deep mb-2">Visi</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{/* GANTI DENGAN DATA ASLI SEKOLAH */}"Terwujudnya peserta didik yang beriman, berkarakter, berprestasi, dan berwawasan lingkungan."</p>
              </div>
              <div className="bg-white rounded-2xl p-7 border border-slate-100 shadow-sm">
                <div className="w-11 h-11 rounded-xl bg-blue-soft flex items-center justify-center mb-4"><Compass size={20} className="text-navy"/></div>
                <h3 className="font-bold text-navy-deep mb-2">Misi</h3>
                <ul className="text-sm text-slate-600 leading-relaxed space-y-2 list-disc pl-4">
                  <li>Menyelenggarakan pembelajaran yang aktif, kreatif, dan menyenangkan.</li>
                  <li>Menumbuhkan nilai keimanan dan akhlak mulia dalam keseharian.</li>
                  <li>Mengembangkan potensi, minat, dan bakat peserta didik secara optimal.</li>
                  <li>Membudayakan gotong royong dan kepedulian terhadap lingkungan.</li>
                </ul>
              </div>
            </div>
          )}
          {tab === "struktur" && (
            <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 sm:p-10 overflow-x-auto">
              <div className="min-w-[560px] flex flex-col items-center gap-4">
                <div className="bg-navy text-white text-xs font-bold px-5 py-3 rounded-xl">Kepala Sekolah</div>
                <div className="w-px h-5 bg-slate-300" />
                <div className="bg-blue-soft text-navy text-xs font-bold px-5 py-3 rounded-xl">Wakil Kepala Sekolah</div>
                <div className="w-px h-5 bg-slate-300" />
                <div className="flex gap-4 flex-wrap justify-center">
                  {["Kurikulum", "Kesiswaan", "Sarana Prasarana", "Humas"].map((r) => (
                    <div key={r} className="bg-gold-pale text-navy-deep text-xs font-bold px-4 py-2.5 rounded-xl">{r}</div>
                  ))}
                </div>
                <div className="w-px h-5 bg-slate-300" />
                <div className="bg-slate-100 text-slate-600 text-xs font-bold px-5 py-3 rounded-xl">Guru, Wali Kelas & Tenaga Kependidikan</div>
              </div>
            </div>
          )}
          {tab === "kepsek" && (
            <div className="grid md:grid-cols-[240px_1fr] gap-8 items-start">
              <div className="rounded-2xl overflow-hidden aspect-square bg-blue-soft flex items-center justify-center border border-slate-100">
                <Users size={56} className="text-navy/25" />
              </div>
              <div>
                <h3 className="font-bold text-navy-deep text-lg">{/* GANTI DENGAN DATA ASLI SEKOLAH */}Dede Suryana, S.Pd., M.M.</h3>
                <div className="text-sm text-gold font-semibold mt-1">Kepala SMP Negeri 5 Gegerbitung</div>
                <p className="mt-4 text-sm text-slate-600 leading-relaxed">Berpengalaman dalam bidang pendidikan dan manajemen sekolah, berkomitmen membawa SMP Negeri 5 Gegerbitung menjadi sekolah yang unggul dalam akademik maupun pembentukan karakter siswa.</p>
              </div>
            </div>
          )}
          {tab === "guru" && (
            <div>
              <p className="text-sm text-slate-500 mb-6">Menampilkan {TEACHERS.length} dari data guru dan tenaga kependidikan. <em>// GANTI DENGAN DATA ASLI SEKOLAH</em></p>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
                {TEACHERS.map((t, i) => (
                  <div key={i} className="card-elevate bg-white rounded-2xl border border-slate-100 shadow-sm p-5 text-center">
                    <div className="w-16 h-16 rounded-full bg-blue-soft mx-auto flex items-center justify-center mb-3">
                      <Users size={26} className="text-navy/40" />
                    </div>
                    <div className="font-bold text-navy-deep text-sm leading-snug">{t.name}</div>
                    <div className="text-[11px] text-gold font-semibold mt-1">{t.role}</div>
                    <div className="text-[11px] text-slate-400 mt-2">NIP: {t.nip}</div>
                    <div className="text-[11px] text-slate-500">{t.subject}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {tab === "sarpras" && (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {[
                { name: "Ruang Kelas", desc: "18 ruang kelas representatif dan nyaman untuk kegiatan belajar." },
                { name: "Laboratorium Komputer", desc: "Mendukung pembelajaran informatika dan asesmen berbasis komputer." },
                { name: "Laboratorium IPA", desc: "Fasilitas praktikum sains untuk pembelajaran yang lebih aplikatif." },
                { name: "Perpustakaan", desc: "Koleksi buku dan pojok literasi untuk menumbuhkan minat baca." },
                { name: "Lapangan Olahraga", desc: "Lapangan multifungsi untuk upacara, olahraga, dan kegiatan siswa." },
                { name: "UKS", desc: "Layanan kesehatan dasar bagi seluruh warga sekolah." },
                { name: "Musala", desc: "Tempat ibadah untuk kegiatan keagamaan sehari-hari." },
                { name: "Kantin Sehat", desc: "Menyediakan makanan bergizi dan terjaga kebersihannya." },
              ].map((f, i) => (
                <div key={i} className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5 card-elevate">
                  <div className="w-10 h-10 rounded-lg bg-gold-pale flex items-center justify-center mb-3"><Building2 size={18} className="text-gold"/></div>
                  <div className="font-bold text-navy-deep text-sm">{f.name}</div>
                  <div className="text-xs text-slate-500 mt-1.5 leading-relaxed">{f.desc}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </Container>
    </div>
  );
};

/* ============================================================
   HALAMAN: PROGRAM SEKOLAH
   ============================================================ */
const ProgramSekolah = () => {
  const [active, setActive] = useState(null);
  return (
    <div>
      <PageIntro icon={Target} title="Program Sekolah" desc="Beragam program unggulan yang dirancang untuk mendukung tumbuh kembang akademik dan karakter siswa." crumbs={["Program Sekolah"]} />
      <Container className="py-12 sm:py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {PROGRAMS.map((p) => (
            <div key={p.key} className="card-elevate bg-white rounded-2xl border border-slate-100 shadow-sm p-6 flex flex-col">
              <div className="w-12 h-12 rounded-xl bg-blue-soft flex items-center justify-center mb-4"><p.icon size={22} className="text-navy"/></div>
              <h3 className="font-bold text-navy-deep">{p.title}</h3>
              <p className="text-sm text-slate-500 mt-2 leading-relaxed flex-1">{p.desc}</p>
              <button onClick={() => setActive(p)} className="mt-4 text-navy font-bold text-sm flex items-center gap-1 self-start">
                Lihat Selengkapnya <ChevronRight size={15} />
              </button>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-navy-deep kawung-bg text-white rounded-3xl p-8 sm:p-12">
          <Badge tone="gold">Sorotan Program</Badge>
          <h3 className="text-xl sm:text-2xl font-extrabold mt-4">Program Kokurikuler SMPN 5 Gegerbitung Tahun Ajaran 2026/2027</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mt-8 text-sm">
            {[
              { label: "Tema", value: "Kearifan Lokal Sukabumi" },
              { label: "Tujuan", value: "Menumbuhkan gotong royong, kreativitas, dan cinta budaya lokal" },
              { label: "Jadwal", value: "Setiap Jumat, 3 kali per semester" },
              { label: "Hasil / Produk", value: "Karya siswa dipamerkan pada gelar karya akhir semester" },
            ].map((f, i) => (
              <div key={i} className="bg-white/5 border border-white/10 rounded-xl p-4">
                <div className="text-gold-light text-xs font-bold uppercase mb-1.5">{f.label}</div>
                <div className="text-white/80 text-[13px] leading-relaxed">{f.value}</div>
              </div>
            ))}
          </div>
        </div>
      </Container>

      <Modal open={!!active} onClose={() => setActive(null)} title={active?.title}>
        {active && (
          <div>
            <p className="text-sm text-slate-600 leading-relaxed mb-4">{active.desc}</p>
            <ul className="space-y-2">
              {active.items.map((it, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-slate-700">
                  <CheckCircle2 size={16} className="text-gold shrink-0 mt-0.5" /> {it}
                </li>
              ))}
            </ul>
          </div>
        )}
      </Modal>
    </div>
  );
};

/* ============================================================
   HALAMAN: KEGIATAN SISWA
   ============================================================ */
const KegiatanSiswa = () => {
  const [tab, setTab] = useState("harian");
  const cat = ACTIVITY_CATEGORIES[tab];
  return (
    <div>
      <PageIntro icon={Sparkles} title="Kegiatan Siswa" desc="Rangkaian kegiatan harian hingga tahunan yang membentuk pengalaman belajar siswa secara menyeluruh." crumbs={["Kegiatan Siswa"]} />
      <Container className="py-12 sm:py-16">
        <Tabs tabs={Object.entries(ACTIVITY_CATEGORIES).map(([k, v]) => ({ key: k, label: v.label }))} active={tab} onChange={setTab} />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-10 fade-in">
          {cat.items.map((it, i) => (
            <div key={i} className="card-elevate bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm">
              <div className="h-32 bg-gradient-to-br from-blue-soft to-white flex items-center justify-center border-b border-slate-50">
                <Sparkles size={26} className="text-navy/25" />
              </div>
              <div className="p-5">
                <h4 className="font-bold text-navy-deep">{it.name}</h4>
                <div className="text-xs text-gold font-semibold mt-1.5 flex items-center gap-1.5"><Clock size={12}/>{it.date}</div>
                <p className="text-xs text-slate-500 mt-2 leading-relaxed line-clamp-2">{it.desc}</p>
                <button className="mt-4 text-navy text-xs font-bold flex items-center gap-1">Lihat Dokumentasi <ChevronRight size={13}/></button>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </div>
  );
};

/* ============================================================
   HALAMAN: EKSTRAKURIKULER
   ============================================================ */
const Ekstrakurikuler = () => {
  const [active, setActive] = useState(null);
  return (
    <div>
      <PageIntro icon={Star} title="Ekstrakurikuler" desc="Wadah pengembangan minat dan bakat siswa di luar jam pelajaran wajib." crumbs={["Ekstrakurikuler"]} />
      <Container className="py-12 sm:py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {EXTRACURRICULARS.map((e, i) => (
            <button key={i} onClick={() => setActive(e)} className="card-elevate text-left bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
              <div className="w-12 h-12 rounded-xl bg-gold-pale flex items-center justify-center mb-4"><e.icon size={22} className="text-gold"/></div>
              <h4 className="font-bold text-navy-deep text-sm">{e.name}</h4>
              <div className="text-xs text-slate-500 mt-2">{e.jadwal}</div>
              <div className="mt-4 text-navy text-xs font-bold flex items-center gap-1">Detail <ChevronRight size={13}/></div>
            </button>
          ))}
        </div>
      </Container>
      <Modal open={!!active} onClose={() => setActive(null)} title={active?.name}>
        {active && (
          <div className="space-y-3 text-sm">
            <p className="text-slate-600 leading-relaxed">{active.desc}</p>
            <div className="flex justify-between border-t border-slate-100 pt-3"><span className="text-slate-400">Pembina</span><span className="font-semibold text-navy-deep">{active.pembina}</span></div>
            <div className="flex justify-between"><span className="text-slate-400">Jadwal</span><span className="font-semibold text-navy-deep">{active.jadwal}</span></div>
          </div>
        )}
      </Modal>
    </div>
  );
};

/* ============================================================
   HALAMAN: AKADEMIK
   ============================================================ */
const AKADEMIK_TABS = [
  { key: "kurikulum", label: "Kurikulum" },
  { key: "kalender", label: "Kalender Pendidikan" },
  { key: "jadwal", label: "Jadwal Pelajaran" },
  { key: "pembelajaran", label: "Program Pembelajaran" },
  { key: "asesmen", label: "Asesmen" },
  { key: "kelulusan", label: "Kriteria Kelulusan" },
];
const Akademik = ({ subTab, setSubTab }) => {
  const tab = subTab || "kurikulum";
  const [q, setQ] = useState("");
  const content = {
    kurikulum: "Sekolah menerapkan Kurikulum Merdeka dengan pendekatan pembelajaran berdiferensiasi yang disesuaikan dengan kebutuhan dan minat peserta didik.",
    kalender: "Kalender pendidikan memuat jadwal awal dan akhir semester, hari efektif belajar, serta hari libur nasional dan keagamaan.",
    jadwal: "Jadwal pelajaran disusun per rombongan belajar dan dapat diunduh melalui halaman Informasi.",
    pembelajaran: "Program pembelajaran meliputi kegiatan intrakurikuler, kokurikuler, dan pembiasaan literasi-numerasi setiap hari.",
    asesmen: "Asesmen dilakukan secara formatif dan sumatif untuk memantau perkembangan capaian belajar siswa secara berkala.",
    kelulusan: "Kriteria kelulusan mengacu pada penyelesaian seluruh program pembelajaran serta capaian sikap dan kompetensi minimal yang ditetapkan sekolah.",
  };
  const filtered = q ? Object.entries(content).filter(([k, v]) => v.toLowerCase().includes(q.toLowerCase()) || k.includes(q.toLowerCase())) : null;
  return (
    <div>
      <PageIntro icon={BookOpen} title="Akademik" desc="Informasi kurikulum, kalender pendidikan, dan proses pembelajaran di SMP Negeri 5 Gegerbitung." crumbs={["Akademik"]} />
      <Container className="py-12 sm:py-16">
        <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-full px-4 py-3 mb-8 max-w-lg shadow-sm">
          <Search size={16} className="text-slate-400" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari informasi akademik..." className="flex-1 outline-none text-sm" />
        </div>
        {filtered ? (
          <div className="space-y-4">
            {filtered.length === 0 && <p className="text-sm text-slate-500">Tidak ditemukan informasi yang sesuai.</p>}
            {filtered.map(([k, v]) => (
              <div key={k} className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
                <h4 className="font-bold text-navy-deep capitalize">{AKADEMIK_TABS.find((t) => t.key === k)?.label}</h4>
                <p className="text-sm text-slate-600 mt-2 leading-relaxed">{v}</p>
              </div>
            ))}
          </div>
        ) : (
          <>
            <Tabs tabs={AKADEMIK_TABS} active={tab} onChange={setSubTab} />
            <div className="mt-8 bg-white rounded-2xl border border-slate-100 shadow-sm p-6 sm:p-8 fade-in max-w-3xl">
              <h3 className="font-bold text-navy-deep text-lg mb-3">{AKADEMIK_TABS.find((t) => t.key === tab)?.label}</h3>
              <p className="text-slate-600 leading-relaxed text-sm">{content[tab]}</p>
              {tab === "jadwal" && (
                <button className="mt-5 flex items-center gap-2 text-sm font-bold text-navy bg-blue-soft px-4 py-2.5 rounded-full">
                  <Download size={15} /> Unduh Jadwal Pelajaran (PDF)
                </button>
              )}
            </div>
          </>
        )}
      </Container>
    </div>
  );
};

/* ============================================================
   HALAMAN: PRESTASI
   ============================================================ */
const Prestasi = () => {
  const [filter, setFilter] = useState("Semua");
  const cats = ["Semua", "Akademik", "Olahraga", "Seni", "Keagamaan", "Lainnya"];
  const list = filter === "Semua" ? ACHIEVEMENTS : ACHIEVEMENTS.filter((a) => a.kategori === filter);
  return (
    <div>
      <PageIntro icon={Trophy} title="Prestasi Siswa" desc="Capaian akademik dan non-akademik yang telah diraih siswa SMP Negeri 5 Gegerbitung." crumbs={["Prestasi"]} />
      <Container className="py-12 sm:py-16">
        <FilterChips options={cats} active={filter} onChange={setFilter} />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          {list.map((a, i) => (
            <div key={i} className="card-elevate bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm">
              <div className="h-32 grad-gold flex items-center justify-center">
                <Trophy size={30} className="text-white/70" />
              </div>
              <div className="p-5">
                <Badge tone="gold">{a.hasil}</Badge>
                <h4 className="font-bold text-navy-deep mt-3">{a.lomba}</h4>
                <div className="text-xs text-slate-500 mt-2 space-y-1">
                  <div>{a.name} · Kelas {a.kelas}</div>
                  <div>Tingkat {a.tingkat} · {a.tanggal}</div>
                </div>
              </div>
            </div>
          ))}
          {list.length === 0 && <p className="text-sm text-slate-500">Belum ada data prestasi pada kategori ini.</p>}
        </div>
      </Container>
    </div>
  );
};

/* ============================================================
   HALAMAN: BERITA
   ============================================================ */
const Berita = () => {
  const [filter, setFilter] = useState("Semua");
  const [active, setActive] = useState(null);
  const cats = ["Semua", "Akademik", "Prestasi", "Kegiatan", "Pengumuman"];
  const list = filter === "Semua" ? NEWS : NEWS.filter((n) => n.category === filter);
  const popular = NEWS.filter((n) => n.popular);
  return (
    <div>
      <PageIntro icon={Newspaper} title="Berita & Informasi" desc="Portal berita resmi seputar kegiatan dan capaian SMP Negeri 5 Gegerbitung." crumbs={["Berita"]} />
      <Container className="py-12 sm:py-16">
        <div className="grid lg:grid-cols-[1fr_300px] gap-10">
          <div>
            <FilterChips options={cats} active={filter} onChange={setFilter} />
            <div className="grid sm:grid-cols-2 gap-6 mt-8">
              {list.map((n, i) => (
                <div key={i} className="card-elevate bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm">
                  <div className="h-36 grad-navy kawung-bg flex items-center justify-center"><Newspaper size={28} className="text-white/40" /></div>
                  <div className="p-5">
                    <Badge tone="navy">{n.category}</Badge>
                    <h3 className="mt-3 font-bold text-navy-deep leading-snug line-clamp-2">{n.title}</h3>
                    <p className="mt-2 text-xs text-slate-500 line-clamp-3">{n.summary}</p>
                    <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
                      <span className="flex items-center gap-1"><Clock size={12}/>{n.date}</span>
                      <button onClick={() => setActive(n)} className="text-navy font-bold">Baca Selengkapnya →</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <aside className="space-y-6 h-fit">
            <div className="bg-blue-soft/60 rounded-2xl p-5">
              <h4 className="font-bold text-navy-deep text-sm mb-4 flex items-center gap-2"><Star size={15} className="text-gold"/> Berita Populer</h4>
              <div className="space-y-4">
                {popular.map((n, i) => (
                  <button key={i} onClick={() => setActive(n)} className="text-left block w-full">
                    <div className="text-xs font-semibold text-navy-deep leading-snug line-clamp-2">{n.title}</div>
                    <div className="text-[11px] text-slate-500 mt-1">{n.date}</div>
                  </button>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </Container>
      <Modal open={!!active} onClose={() => setActive(null)} title={active?.category}>
        {active && (
          <div>
            <h3 className="font-bold text-navy-deep text-lg leading-snug">{active.title}</h3>
            <div className="text-xs text-slate-400 mt-2 flex items-center gap-1.5"><Clock size={12}/>{active.date}</div>
            <p className="text-sm text-slate-600 leading-relaxed mt-4">{active.summary} Informasi lebih lanjut akan diperbarui melalui laman berita resmi sekolah dan papan pengumuman.</p>
          </div>
        )}
      </Modal>
    </div>
  );
};

/* ============================================================
   HALAMAN: GALERI
   ============================================================ */
const Galeri = () => {
  const [filter, setFilter] = useState("Semua");
  const [active, setActive] = useState(null);
  const list = filter === "Semua" ? GALLERY_ITEMS : GALLERY_ITEMS.filter((g) => g.category === filter);
  return (
    <div>
      <PageIntro icon={ImageIcon} title="Galeri" desc="Dokumentasi visual kegiatan, pembelajaran, dan prestasi warga sekolah." crumbs={["Galeri"]} />
      <Container className="py-12 sm:py-16">
        <FilterChips options={GALLERY_CATEGORIES} active={filter} onChange={setFilter} />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 mt-8">
          {list.map((g) => (
            <button
              key={g.id}
              onClick={() => setActive(g)}
              className="card-elevate rounded-2xl overflow-hidden aspect-square flex items-center justify-center relative group"
              style={{ background: `linear-gradient(135deg, hsl(${g.hue} 55% 30%), hsl(${g.hue} 55% 50%))` }}
            >
              <Camera size={26} className="text-white/60" />
              <div className="absolute inset-x-0 bottom-0 bg-black/40 text-white text-[10px] px-2 py-1.5 text-left opacity-0 group-hover:opacity-100 transition-opacity">
                {g.category}
              </div>
            </button>
          ))}
        </div>
      </Container>
      <Modal open={!!active} onClose={() => setActive(null)} title={active?.title}>
        {active && (
          <div>
            <div className="rounded-2xl aspect-video flex items-center justify-center mb-4" style={{ background: `linear-gradient(135deg, hsl(${active.hue} 55% 30%), hsl(${active.hue} 55% 50%))` }}>
              <Camera size={40} className="text-white/60" />
            </div>
            <Badge tone="navy">{active.category}</Badge>
            <p className="text-xs text-slate-400 mt-3">Foto dokumentasi kegiatan sekolah. // GANTI DENGAN DATA ASLI SEKOLAH</p>
          </div>
        )}
      </Modal>
    </div>
  );
};

/* ============================================================
   HALAMAN: INFORMASI
   ============================================================ */
const Informasi = () => (
  <div>
    <PageIntro icon={Info} title="Informasi" desc="Pengumuman, dokumen unduhan, dan informasi penting bagi siswa dan orang tua." crumbs={["Informasi"]} />
    <Container className="py-12 sm:py-16 space-y-14">
      <div>
        <SectionHeading eyebrow="Pengumuman" title="Pengumuman Terbaru" />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {ANNOUNCEMENTS.map((a, i) => (
            <div key={i} className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
              <Badge tone="gold">{a.date}</Badge>
              <h4 className="font-bold text-navy-deep mt-3 text-sm">{a.title}</h4>
              <p className="text-xs text-slate-500 mt-2 leading-relaxed">{a.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <div>
        <SectionHeading eyebrow="Unduhan" title="Formulir & Dokumen Sekolah" />
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm divide-y divide-slate-100">
          {DOCUMENTS.map((d, i) => (
            <div key={i} className="flex items-center justify-between p-4 sm:p-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-soft flex items-center justify-center shrink-0"><FileText size={18} className="text-navy"/></div>
                <div>
                  <div className="text-sm font-semibold text-navy-deep">{d.name}</div>
                  <div className="text-[11px] text-slate-400">{d.type} · {d.size}</div>
                </div>
              </div>
              <button className="w-9 h-9 rounded-full bg-blue-soft hover:bg-gold hover:text-navy-deep flex items-center justify-center transition-colors shrink-0"><Download size={16}/></button>
            </div>
          ))}
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-6">
        <div className="grad-navy kawung-bg rounded-2xl p-7 text-white">
          <h4 className="font-bold text-lg mb-2">Informasi PPDB</h4>
          <p className="text-sm text-white/75 leading-relaxed">Pendaftaran Peserta Didik Baru dilakukan secara daring dan luring sesuai jadwal resmi dari Dinas Pendidikan Kabupaten Sukabumi. Pantau halaman ini untuk pembaruan jadwal terbaru.</p>
        </div>
        <div className="bg-gold-pale rounded-2xl p-7">
          <h4 className="font-bold text-navy-deep text-lg mb-2">Untuk Orang Tua & Siswa</h4>
          <p className="text-sm text-navy-deep/70 leading-relaxed">Layanan konsultasi wali kelas, informasi nilai, dan komunikasi sekolah dapat diakses melalui grup resmi masing-masing kelas atau langsung menghubungi bagian tata usaha.</p>
        </div>
      </div>
    </Container>
  </div>
);

/* ============================================================
   HALAMAN: AGENDA
   ============================================================ */
const Agenda = () => (
  <div>
    <PageIntro icon={Calendar} title="Agenda Sekolah" desc="Jadwal kegiatan sekolah yang akan berlangsung dalam waktu dekat." crumbs={["Agenda"]} />
    <Container className="py-12 sm:py-16">
      <div className="space-y-4 max-w-2xl">
        {AGENDA_ITEMS.map((a, i) => (
          <div key={i} className="card-elevate bg-white rounded-2xl border border-slate-100 shadow-sm p-5 flex gap-5 items-start">
            <div className="w-16 shrink-0 text-center bg-blue-soft rounded-xl py-2.5">
              <div className="text-lg font-extrabold text-navy leading-none">{a.date.split(" ")[0]}</div>
              <div className="text-[10px] font-bold text-navy/70 uppercase mt-1">{a.date.split(" ")[1]}</div>
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-navy-deep">{a.title}</h4>
              <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-xs text-slate-500">
                <span className="flex items-center gap-1.5"><Clock size={12}/>{a.time}</span>
                <span className="flex items-center gap-1.5"><MapPin size={12}/>{a.place}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Container>
  </div>
);

/* ============================================================
   HALAMAN: KONTAK
   ============================================================ */
const Kontak = () => {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ nama: "", email: "", subjek: "", pesan: "" });
  return (
    <div>
      <PageIntro icon={Phone} title="Kontak" desc="Hubungi kami untuk pertanyaan, informasi, atau kerja sama dengan SMP Negeri 5 Gegerbitung." crumbs={["Kontak"]} />
      <Container className="py-12 sm:py-16">
        <div className="grid lg:grid-cols-2 gap-10">
          <div>
            <div className="space-y-4 mb-8">
              {[
                { icon: MapPin, label: "Alamat", value: SCHOOL.address },
                { icon: Phone, label: "Telepon", value: SCHOOL.phone },
                { icon: Mail, label: "Email", value: SCHOOL.email },
                { icon: MessageCircle, label: "WhatsApp", value: `+${SCHOOL.whatsapp}` },
              ].map((c, i) => (
                <div key={i} className="flex items-start gap-4 bg-white rounded-2xl border border-slate-100 shadow-sm p-4">
                  <div className="w-10 h-10 rounded-xl bg-blue-soft flex items-center justify-center shrink-0"><c.icon size={18} className="text-navy"/></div>
                  <div>
                    <div className="text-xs text-slate-400">{c.label}</div>
                    <div className="text-sm font-semibold text-navy-deep">{c.value}</div>
                  </div>
                </div>
              ))}
            </div>
            <div className="rounded-2xl overflow-hidden border border-slate-100 shadow-sm aspect-video bg-blue-soft flex items-center justify-center">
              <div className="text-center text-navy/50 text-xs">
                <MapPin size={26} className="mx-auto mb-2" />
                Peta lokasi Google Maps<br/>// GANTI DENGAN EMBED PETA ASLI SEKOLAH
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              {[Facebook, Instagram, Youtube].map((Icon, i) => (
                <a key={i} href="#" onClick={(e) => e.preventDefault()} className="w-10 h-10 rounded-full bg-blue-soft hover:bg-navy hover:text-white flex items-center justify-center transition-colors text-navy">
                  <Icon size={17} />
                </a>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 sm:p-8">
            <h3 className="font-bold text-navy-deep text-lg mb-1">Kirim Pesan</h3>
            <p className="text-xs text-slate-500 mb-6">Isi formulir berikut, tim kami akan merespons secepatnya.</p>
            {sent ? (
              <div className="text-center py-10">
                <CheckCircle2 size={40} className="text-gold mx-auto mb-3" />
                <div className="font-bold text-navy-deep">Pesan Terkirim</div>
                <p className="text-xs text-slate-500 mt-1">Terima kasih, pesan Anda telah kami terima.</p>
                <button onClick={() => { setSent(false); setForm({ nama: "", email: "", subjek: "", pesan: "" }); }} className="mt-5 text-navy text-sm font-bold">Kirim pesan lain</button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <input value={form.nama} onChange={(e) => setForm({ ...form, nama: e.target.value })} placeholder="Nama" className="border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-navy" />
                  <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="Email" className="border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-navy" />
                </div>
                <input value={form.subjek} onChange={(e) => setForm({ ...form, subjek: e.target.value })} placeholder="Subjek" className="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-navy" />
                <textarea value={form.pesan} onChange={(e) => setForm({ ...form, pesan: e.target.value })} placeholder="Pesan" rows={4} className="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-navy resize-none" />
                <button
                  onClick={() => { if (form.nama && form.pesan) setSent(true); }}
                  className="btn-primary w-full py-3.5 rounded-xl text-sm flex items-center justify-center gap-2"
                >
                  Kirim Pesan <Send size={15} />
                </button>
              </div>
            )}
          </div>
        </div>
      </Container>
    </div>
  );
};

/* ============================================================
   DASHBOARD ADMIN (simulasi frontend, tanpa backend)
   ============================================================ */
const ADMIN_TABS = [
  { key: "ringkasan", label: "Ringkasan", icon: LayoutDashboard },
  { key: "berita", label: "Berita", icon: Newspaper },
  { key: "kegiatan", label: "Kegiatan", icon: Sparkles },
  { key: "prestasi", label: "Prestasi", icon: Trophy },
  { key: "galeri", label: "Galeri", icon: ImageIcon },
  { key: "dokumen", label: "Dokumen", icon: FileText },
  { key: "agenda", label: "Agenda", icon: Calendar },
];

const AdminLogin = ({ onLogin, onBack }) => (
  <div className="min-h-screen grad-navy kawung-bg flex items-center justify-center p-6">
    <div className="bg-white rounded-3xl shadow-2xl p-8 sm:p-10 w-full max-w-sm fade-up">
      <div className="flex flex-col items-center mb-6">
        <SchoolLogo size={52} />
        <h2 className="font-bold text-navy-deep mt-4">Dashboard Admin</h2>
        <p className="text-xs text-slate-500 mt-1 text-center">{SCHOOL.name}</p>
      </div>
      <div className="space-y-3 mb-5">
        <input placeholder="Nama pengguna" defaultValue="admin" className="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-navy" />
        <input placeholder="Kata sandi" type="password" defaultValue="demo123" className="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-navy" />
      </div>
      <button onClick={onLogin} className="btn-primary w-full py-3.5 rounded-xl text-sm">Masuk sebagai Admin (Demo)</button>
      <button onClick={onBack} className="w-full py-3 text-xs text-slate-400 mt-2 hover:text-navy">← Kembali ke website</button>
      <p className="text-[10px] text-slate-400 text-center mt-4">Mode simulasi — belum terhubung ke server sungguhan.</p>
    </div>
  </div>
);

const Toast = ({ message }) => !message ? null : (
  <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[200] bg-navy-deep text-white text-xs font-semibold px-5 py-3 rounded-full shadow-2xl fade-up">
    {message}
  </div>
);

const AdminTable = ({ columns, rows, onSimulate }) => (
  <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-x-auto">
    <table className="w-full text-sm min-w-[520px]">
      <thead>
        <tr className="bg-blue-soft/60 text-navy-deep text-xs uppercase text-left">
          {columns.map((c) => <th key={c} className="px-4 py-3 font-bold">{c}</th>)}
          <th className="px-4 py-3 font-bold text-right">Aksi</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-slate-100">
        {rows.map((r, i) => (
          <tr key={i} className="hover:bg-slate-50">
            {r.map((cell, j) => <td key={j} className="px-4 py-3 text-slate-600">{cell}</td>)}
            <td className="px-4 py-3">
              <div className="flex justify-end gap-2">
                <button onClick={onSimulate} className="w-8 h-8 rounded-lg bg-blue-soft hover:bg-navy hover:text-white flex items-center justify-center text-navy"><Edit size={14}/></button>
                <button onClick={onSimulate} className="w-8 h-8 rounded-lg bg-red-50 hover:bg-red-500 hover:text-white flex items-center justify-center text-red-500"><Trash2 size={14}/></button>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

const AdminDashboard = ({ onExit }) => {
  const [tab, setTab] = useState("ringkasan");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [toast, setToast] = useState("");
  const [newsList, setNewsList] = useState(NEWS.map((n, i) => ({ id: i, ...n })));
  const [draft, setDraft] = useState({ title: "", category: "Kegiatan", date: "", summary: "" });

  const flash = (msg) => { setToast(msg); setTimeout(() => setToast(""), 2200); };

  const addNews = () => {
    if (!draft.title) { flash("Judul berita wajib diisi"); return; }
    setNewsList([{ id: Date.now(), popular: false, ...draft, date: draft.date || "Hari ini" }, ...newsList]);
    setDraft({ title: "", category: "Kegiatan", date: "", summary: "" });
    flash("Berita berhasil ditambahkan (simulasi)");
  };
  const deleteNews = (id) => { setNewsList(newsList.filter((n) => n.id !== id)); flash("Berita dihapus (simulasi)"); };

  return (
    <div className="min-h-screen bg-paper flex">
      <GlobalStyles />
      <Toast message={toast} />
      {/* Sidebar */}
      <aside className={`fixed lg:sticky top-0 h-screen z-40 w-64 grad-navy text-white flex flex-col transition-transform ${sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}>
        <div className="flex items-center gap-2.5 p-5 border-b border-white/10">
          <SchoolLogo size={34} />
          <div>
            <div className="font-bold text-sm leading-tight">Admin Panel</div>
            <div className="text-[10px] text-white/60">{SCHOOL.shortName}</div>
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {ADMIN_TABS.map((t) => (
            <button key={t.key} onClick={() => { setTab(t.key); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-colors ${tab === t.key ? "bg-gold text-navy-deep" : "text-white/75 hover:bg-white/10"}`}>
              <t.icon size={17} /> {t.label}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-white/10">
          <button onClick={onExit} className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold text-white/75 hover:bg-white/10">
            <LogOut size={17} /> Keluar
          </button>
        </div>
      </aside>
      {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      <main className="flex-1 min-w-0">
        <div className="bg-white border-b border-slate-100 px-5 sm:px-8 py-4 flex items-center justify-between sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center"><Menu size={18}/></button>
            <h2 className="font-bold text-navy-deep">{ADMIN_TABS.find((t) => t.key === tab)?.label}</h2>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400"><UserCog size={16}/> Admin Demo</div>
        </div>

        <div className="p-5 sm:p-8">
          {tab === "ringkasan" && (
            <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {STATS.map((s) => (
                <div key={s.label} className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
                  <s.icon size={20} className="text-gold mb-3" />
                  <div className="text-2xl font-extrabold text-navy-deep">{s.value}</div>
                  <div className="text-xs text-slate-500 mt-1">{s.label}</div>
                </div>
              ))}
              <div className="sm:col-span-2 lg:col-span-5 bg-gold-pale rounded-2xl p-6 text-navy-deep text-sm leading-relaxed">
                Ini adalah simulasi dashboard admin dengan data dummy, disiapkan agar strukturnya mudah dikembangkan menjadi CMS sungguhan. Semua aksi tambah/edit/hapus di sini hanya mengubah tampilan sementara di peramban.
              </div>
            </div>
          )}

          {tab === "berita" && (
            <div className="space-y-6">
              <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
                <h3 className="font-bold text-navy-deep text-sm mb-4 flex items-center gap-2"><Plus size={15}/> Tambah Berita</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  <input value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} placeholder="Judul berita" className="border border-slate-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-navy" />
                  <select value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value })} className="border border-slate-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-navy">
                    {["Akademik", "Prestasi", "Kegiatan", "Pengumuman"].map((c) => <option key={c}>{c}</option>)}
                  </select>
                  <textarea value={draft.summary} onChange={(e) => setDraft({ ...draft, summary: e.target.value })} placeholder="Ringkasan singkat" rows={2} className="sm:col-span-2 border border-slate-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-navy resize-none" />
                </div>
                <button onClick={addNews} className="btn-primary mt-4 px-5 py-2.5 rounded-xl text-sm flex items-center gap-2"><Plus size={15}/> Simpan Berita</button>
              </div>
              <AdminTable
                columns={["Judul", "Kategori", "Tanggal"]}
                rows={newsList.map((n) => [n.title, n.category, n.date])}
                onSimulate={() => flash("Fitur ini aktif setelah backend terhubung")}
              />
            </div>
          )}

          {tab === "kegiatan" && (
            <AdminTable columns={["Nama Kegiatan", "Tanggal", "Kategori"]}
              rows={Object.values(ACTIVITY_CATEGORIES).flatMap((c) => c.items.slice(0, 2).map((i) => [i.name, i.date, c.label]))}
              onSimulate={() => flash("Fitur ini aktif setelah backend terhubung")} />
          )}
          {tab === "prestasi" && (
            <AdminTable columns={["Nama Siswa", "Lomba", "Hasil"]}
              rows={ACHIEVEMENTS.map((a) => [a.name, a.lomba, a.hasil])}
              onSimulate={() => flash("Fitur ini aktif setelah backend terhubung")} />
          )}
          {tab === "galeri" && (
            <div className="space-y-5">
              <button onClick={() => flash("Unggah foto aktif setelah backend terhubung")} className="btn-primary px-5 py-2.5 rounded-xl text-sm flex items-center gap-2"><UploadCloud size={15}/> Unggah Foto</button>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
                {GALLERY_ITEMS.slice(0, 12).map((g) => (
                  <div key={g.id} className="aspect-square rounded-xl flex items-center justify-center relative" style={{ background: `linear-gradient(135deg, hsl(${g.hue} 55% 30%), hsl(${g.hue} 55% 50%))` }}>
                    <Camera size={16} className="text-white/60" />
                    <button onClick={() => flash("Fitur ini aktif setelah backend terhubung")} className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/40 flex items-center justify-center"><X size={11} className="text-white"/></button>
                  </div>
                ))}
              </div>
            </div>
          )}
          {tab === "dokumen" && (
            <div className="space-y-5">
              <button onClick={() => flash("Unggah dokumen aktif setelah backend terhubung")} className="btn-primary px-5 py-2.5 rounded-xl text-sm flex items-center gap-2"><UploadCloud size={15}/> Unggah Dokumen</button>
              <AdminTable columns={["Nama Dokumen", "Tipe", "Ukuran"]} rows={DOCUMENTS.map((d) => [d.name, d.type, d.size])} onSimulate={() => flash("Fitur ini aktif setelah backend terhubung")} />
            </div>
          )}
          {tab === "agenda" && (
            <div className="space-y-5">
              <button onClick={() => flash("Tambah agenda aktif setelah backend terhubung")} className="btn-primary px-5 py-2.5 rounded-xl text-sm flex items-center gap-2"><Plus size={15}/> Tambah Agenda</button>
              <AdminTable columns={["Kegiatan", "Tanggal", "Tempat"]} rows={AGENDA_ITEMS.map((a) => [a.title, a.date, a.place])} onSimulate={() => flash("Fitur ini aktif setelah backend terhubung")} />
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

/* ============================================================
   APLIKASI UTAMA
   ============================================================ */
export default function App() {
  const [page, setPage] = useState("beranda");
  const [subTab, setSubTab] = useState({});
  const [adminMode, setAdminMode] = useState(null); // null | 'login' | 'dashboard'
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 700);
    return () => clearTimeout(t);
  }, []);

  const goTo = (p, s) => {
    setPage(p);
    if (s) setSubTab((prev) => ({ ...prev, [p]: s }));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSearch = (q) => {
    if (!q) return;
    goTo("berita");
  };

  if (adminMode === "login") {
    return <div className="smpn5-root"><GlobalStyles /><AdminLogin onLogin={() => setAdminMode("dashboard")} onBack={() => setAdminMode(null)} /></div>;
  }
  if (adminMode === "dashboard") {
    return <div className="smpn5-root"><AdminDashboard onExit={() => setAdminMode(null)} /></div>;
  }

  const pages = {
    beranda: <Beranda goTo={goTo} />,
    profil: <Profil subTab={subTab.profil} setSubTab={(s) => goTo("profil", s)} />,
    program: <ProgramSekolah />,
    kegiatan: <KegiatanSiswa />,
    ekskul: <Ekstrakurikuler />,
    akademik: <Akademik subTab={subTab.akademik} setSubTab={(s) => goTo("akademik", s)} />,
    prestasi: <Prestasi />,
    berita: <Berita />,
    galeri: <Galeri />,
    informasi: <Informasi />,
    agenda: <Agenda />,
    kontak: <Kontak />,
  };

  return (
    <div className="smpn5-root min-h-screen">
      <GlobalStyles />
      {loading && (
        <div className="fixed inset-0 z-[300] grad-navy flex flex-col items-center justify-center gap-4">
          <SchoolLogo size={60} />
          <Loader2 size={22} className="text-gold-light animate-spin" />
        </div>
      )}
      <Header page={page} subTab={subTab[page]} goTo={goTo} onSearch={handleSearch} />
      <main className="fade-in" key={page}>{pages[page] || pages.beranda}</main>
      <Footer goTo={goTo} openAdmin={() => setAdminMode("login")} />
      <WhatsAppFab />
      <BackToTop />
    </div>
  );
}
