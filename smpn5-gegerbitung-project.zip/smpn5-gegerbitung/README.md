# Website SMP Negeri 5 Gegerbitung

Project React + Vite berdasarkan desain website sekolah.

## Menjalankan di komputer

1. Install Node.js versi LTS.
2. Buka terminal di folder project.
3. Jalankan `npm install`.
4. Jalankan `npm run dev`.
5. Buka alamat yang diberikan Vite.

## Build untuk online

`npm run build`

Hasil website ada di folder `dist/`.

> Catatan: dashboard admin pada versi ini masih simulasi frontend. Database, autentikasi aman, upload file, dan CMS akan dipasang pada tahap berikutnya.
